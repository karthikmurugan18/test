package com.example.demo;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class FibonacciController {
	@RequestMapping(value="/fibonacci/generate", method=RequestMethod.POST, consumes = "application/json")
	
	public int[] generateseries(@RequestBody FibonacciModel f)
	{
		int[] arr=new int[10];
		 System.out.print(f.getN1()+" "+f.getN2());
		 arr[0]=f.getN1();
		 arr[1]=f.getN2();
		 
		 for(int i=2;i<f.getCount();i++) 
		 {    
		  f.setN3(f.getN1() + f.getN2());    
		 System.out.print(" "+f.getN3());
		  arr[i]=f.getN3();
		  f.setN1(f.getN2());    
		  f.setN2(f.getN3());    
		 }  
		 return arr;
		 
	}
	

}
